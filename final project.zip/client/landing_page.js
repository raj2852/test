Template.landing_page.helpers({
 /* plates:function(){
    var plates = Plates.find({"active":true}).fetch();
    return plates; 
  },*/

  test: function () {
		//var db db.plates.aggregate([{$lookup:{from:"tables",localField:"table",foreignField:"_id",as:"objTable"}}]).fetch();

        return 'pippo';
    }
 
});